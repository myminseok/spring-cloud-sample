package com.example.greetermessages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreeterMessagesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreeterMessagesApplication.class, args);
	}

}
