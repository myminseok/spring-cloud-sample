package com.example.greetermessages;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreeterMessagesApplicationTests {

	@Test
	void contextLoads() {
	}

}
